# Trained model

Run `python src/train.py` to create `Dragon.joblib` in this folder. Generated model files are ignored by Git by default.
