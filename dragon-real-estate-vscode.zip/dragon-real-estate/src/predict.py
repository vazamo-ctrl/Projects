"""Load the saved Dragon Real Estate pipeline and predict a property's MEDV."""

from pathlib import Path
import argparse
import joblib
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL = PROJECT_ROOT / "models" / "Dragon.joblib"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="CSV containing the same feature columns used during training.",
    )
    args = parser.parse_args()

    artifact = joblib.load(args.model)
    pipeline = artifact["pipeline"]
    features = artifact["feature_columns"]

    rows = pd.read_csv(args.input)
    missing = [column for column in features if column not in rows.columns]
    if missing:
        raise ValueError(f"Input CSV is missing required columns: {missing}")

    predictions = pipeline.predict(rows[features])
    result = rows.copy()
    result["predicted_medv"] = predictions
    print(result[["predicted_medv"]].to_string(index=False))


if __name__ == "__main__":
    main()
