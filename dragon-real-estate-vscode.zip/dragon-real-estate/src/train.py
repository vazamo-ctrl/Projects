"""
Dragon Real Estate - house price prediction training script.

Expected input: data/data.csv
Target column: medv
"""

from pathlib import Path
import argparse

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeRegressor


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = PROJECT_ROOT / "data" / "data.csv"
DEFAULT_MODEL = PROJECT_ROOT / "models" / "Dragon.joblib"
TARGET = "medv"


def load_data(path: Path) -> pd.DataFrame:
    """Read the CSV and remove empty spreadsheet-export columns."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}\n"
            "Place your housing CSV at data/data.csv (or pass --data PATH)."
        )

    data = pd.read_csv(path)
    data = data.dropna(axis=1, how="all")
    data = data.loc[:, ~data.columns.astype(str).str.match(r"^Unnamed")]
    if TARGET not in data.columns:
        raise ValueError(
            f"Target column '{TARGET}' was not found. "
            f"Available columns: {list(data.columns)}"
        )
    data = data.dropna(subset=[TARGET])
    return data


def build_pipeline(feature_columns) -> Pipeline:
    """Impute missing numeric values, scale features, and fit a regressor."""
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    preprocessor = ColumnTransformer(
        transformers=[("numeric", numeric_pipeline, feature_columns)],
        remainder="drop",
    )
    return Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", DecisionTreeRegressor(random_state=42)),
        ]
    )


def main(data_path: Path, model_path: Path) -> None:
    data = load_data(data_path)
    X = data.drop(columns=[TARGET])
    y = data[TARGET]

    # Match the notebook's stratified split using the CHAS column when present.
    stratify = data["chas"] if "chas" in data.columns else None
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=stratify,
    )

    feature_columns = X_train.select_dtypes(include=np.number).columns.tolist()
    if not feature_columns:
        raise ValueError("No numeric feature columns were found in the dataset.")

    X_train = X_train[feature_columns]
    X_test = X_test[feature_columns]
    pipeline = build_pipeline(feature_columns)

    # Cross-validation is performed on the training data only.
    cv_scores = cross_val_score(
        pipeline,
        X_train,
        y_train,
        scoring="neg_mean_squared_error",
        cv=10,
    )
    cv_rmse = np.sqrt(-cv_scores)
    print(f"Cross-validation RMSE: {cv_rmse.mean():.3f} ± {cv_rmse.std():.3f}")

    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)

    rmse = np.sqrt(mean_squared_error(y_test, predictions))
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    print("\nTest set results")
    print(f"RMSE: {rmse:.3f}")
    print(f"MAE:  {mae:.3f}")
    print(f"R²:   {r2:.3f}")

    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(
        {
            "pipeline": pipeline,
            "feature_columns": feature_columns,
            "target": TARGET,
        },
        model_path,
    )
    print(f"\nSaved trained model to: {model_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train the Dragon Real Estate model.")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA, help="Path to housing CSV.")
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL, help="Output model path.")
    args = parser.parse_args()
    main(args.data, args.model)
