# Dataset

Put the housing dataset CSV here and name it `data.csv`.

The notebook reads a CSV with a target column named `medv`. Its output shows 506 rows and a `chas` column, but the CSV itself was not included with the uploaded notebook.

Do not commit private or licensed datasets unless you have permission. CSV files in this folder are excluded by `.gitignore`.
