# Dragon Real Estate — House Price Prediction

A VS Code-ready Python project converted from the uploaded Jupyter notebook. It follows the notebook's workflow: load housing data, make a stratified train/test split using `chas` when available, impute missing numeric values, scale features, train a Decision Tree regressor, evaluate with cross-validation and test metrics, and save the trained pipeline.

## Project structure

```text
dragon-real-estate/
├── data/README.md
├── models/README.md
├── notebooks/Dragon Real Estate.ipynb
├── src/
│   ├── train.py
│   └── predict.py
├── .vscode/extensions.json
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. Open in VS Code

Open this folder in VS Code using **File → Open Folder**. Install the recommended Python, Pylance, and Jupyter extensions if prompted.

## 2. Set up Python

Open the VS Code terminal in the project root.

**Windows (PowerShell):**
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## 3. Add the dataset

Copy your housing CSV into `data/` and name it `data.csv`. It must contain a target column named `medv`. The notebook output indicates 506 rows and a `chas` column. The uploaded notebook did **not** include the actual CSV, so add it before training.

## 4. Train the model

```bash
python src/train.py
```

Optional custom paths:
```bash
python src/train.py --data data/data.csv --model models/Dragon.joblib
```

The script reports 10-fold cross-validation RMSE and test-set RMSE, MAE, and R², then saves the complete preprocessing + model pipeline to `models/Dragon.joblib`.

## 5. Predict

Create a CSV with the same feature columns as the training data (without the `medv` target), then run:
```bash
python src/predict.py --input path/to/new_properties.csv
```

## 6. Push to GitHub

Create an empty repository on GitHub, then run these commands from this folder:
```bash
git init
git add .
git commit -m "Set up Dragon Real Estate ML project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/dragon-real-estate.git
git push -u origin main
```
Replace the remote URL with your repository URL.

## Notes

- The notebook has incomplete or misspelled cells in the model and evaluation sections. The standalone scripts correct these so the workflow can run.
- The conversion retains the notebook's intended Decision Tree regressor.
- The notebook explores a `taxrm` feature, but the training script does not use it; this avoids a mismatch between training and prediction features.
- Local CSV data and generated model files are excluded from Git by `.gitignore`.
